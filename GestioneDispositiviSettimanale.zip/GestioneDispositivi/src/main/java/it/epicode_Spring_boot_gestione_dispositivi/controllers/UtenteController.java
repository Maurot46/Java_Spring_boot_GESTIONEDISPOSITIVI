package it.epicode_Spring_boot_gestione_dispositivi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode_Spring_boot_gestione_dispositivi.entities.Utente;
import it.epicode_Spring_boot_gestione_dispositivi.services.UtenteService;

@RestController
@RequestMapping("/api/utenti")
public class UtenteController {
	@Autowired
    private UtenteService utenteService;

    @GetMapping("")
    public List<Utente> getAllUtenti() {
        return utenteService.getUtenti();
    }

    @GetMapping("/{id}")
    public Utente getUtenteById(@PathVariable Long id) {
        return utenteService.getUtenteById(id);
    }

    @PostMapping("")
    public Utente createUtente(@RequestBody Utente utente) {
        return utenteService.createUtente(utente);
    }

    @PutMapping("/{id}")
    public Utente updateUtente(@PathVariable Long id, @RequestBody Utente utente) {
        return utenteService.updateUtente(id, utente);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void deleteUtente(@PathVariable Long id) {
        utenteService.deleteUtente(id);
    }
}
