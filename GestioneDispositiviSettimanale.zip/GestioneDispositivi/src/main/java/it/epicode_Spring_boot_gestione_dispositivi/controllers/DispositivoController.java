package it.epicode_Spring_boot_gestione_dispositivi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode_Spring_boot_gestione_dispositivi.entities.Dispositivo;
import it.epicode_Spring_boot_gestione_dispositivi.services.DispositivoService;

@RestController
@RequestMapping("/api/dispositivi")
public class DispositivoController {
	@Autowired
    private DispositivoService dispositivoService;

    @GetMapping("")
    public List<Dispositivo> getAllDispositivi() {
        return dispositivoService.getDispositivi();
    }

    @GetMapping("/{id}")
    public Dispositivo getDispositivoById(@PathVariable Long id) {
        return dispositivoService.getDispositivoById(id);
    }

    @PostMapping("")
    public Dispositivo createDispositivo(@RequestBody Dispositivo dispositivo) {
        return dispositivoService.createDispositivo(dispositivo);
    }

    @PutMapping("/{id}")
    public Dispositivo updateDispositivo(@PathVariable Long id, @RequestBody Dispositivo dispositivo) {
        return dispositivoService.updateDispositivo(id, dispositivo);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void deleteDispositivo(@PathVariable Long id) {
        dispositivoService.deleteDispositivo(id);
    }
}
