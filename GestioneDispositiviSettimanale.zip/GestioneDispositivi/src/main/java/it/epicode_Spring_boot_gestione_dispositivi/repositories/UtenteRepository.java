package it.epicode_Spring_boot_gestione_dispositivi.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.epicode_Spring_boot_gestione_dispositivi.entities.Utente;

@Repository
public interface UtenteRepository extends JpaRepository<Utente, Long>{
	Optional<Utente> findByUsername(String username);;
}
