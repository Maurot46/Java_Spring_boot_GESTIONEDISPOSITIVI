package it.epicode_Spring_boot_gestione_dispositivi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.epicode_Spring_boot_gestione_dispositivi.entities.Role;
@Repository
public interface RoleRepository extends JpaRepository<Role, Integer>{

}
