package it.epicode_Spring_boot_gestione_dispositivi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_Spring_boot_gestione_dispositivi.configs.NotFoundException;
import it.epicode_Spring_boot_gestione_dispositivi.entities.Dispositivo;
import it.epicode_Spring_boot_gestione_dispositivi.entities.Utente;
import it.epicode_Spring_boot_gestione_dispositivi.repositories.DispositivoRepository;
import it.epicode_Spring_boot_gestione_dispositivi.repositories.UtenteRepository;

@Service
public class UtenteService {
	@Autowired
    private UtenteRepository utenteRepository;
	@Autowired
	private DispositivoRepository dispositivoRepository;

    public List<Utente> getUtenti() {
        return utenteRepository.findAll();
    }

    public Utente getUtenteById(Long id) {
        return utenteRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Utente non trovato"));
    }

    public Utente createUtente(Utente utente) {
        return utenteRepository.save(utente);
    }

    public Utente updateUtente(Long id, Utente utente) {
        Utente existingUtente = utenteRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Utente non trovato"));
        existingUtente.setUsername(utente.getUsername());
        existingUtente.setNome(utente.getNome());
        existingUtente.setCognome(utente.getCognome());
        existingUtente.setEmail(utente.getEmail());
        existingUtente.setPassword(utente.getPassword());
        return utenteRepository.save(existingUtente);
    }

    public void deleteUtente(Long id) {
        Utente utente = utenteRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Utente non trovato"));
        utenteRepository.delete(utente);
    }

    public void assegnaDispositivo(Long idUtente, Long idDispositivo) {
        Utente utente = utenteRepository.findById(idUtente)
                .orElseThrow(() -> new NotFoundException("Utente non trovato"));
        Dispositivo dispositivo = dispositivoRepository.findById(idDispositivo)
                .orElseThrow(() -> new NotFoundException("Dispositivo non trovato"));
        utente.getDispositivi().add(dispositivo);
        dispositivo.getUtenti().add(utente);
        utenteRepository.save(utente);
    }

    public void rimuoviDispositivo(Long idUtente, Long idDispositivo) {
        Utente utente = utenteRepository.findById(idUtente)
                .orElseThrow(() -> new NotFoundException("Utente non trovato"));
        Dispositivo dispositivo = dispositivoRepository.findById(idDispositivo)
                .orElseThrow(() -> new NotFoundException("Dispositivo non trovato"));
        utente.getDispositivi().remove(dispositivo);
        dispositivo.getUtenti().remove(utente);
        utenteRepository.save(utente);
    }
}
