package it.epicode_Spring_boot_gestione_dispositivi.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_Spring_boot_gestione_dispositivi.entities.Role;
import it.epicode_Spring_boot_gestione_dispositivi.repositories.RoleRepository;
@Service
public class RoleService {
	@Autowired
	RoleRepository repo;
	
	public void addRole(Role r) {
		repo.save(r);
	}
	
	public Optional<Role> getById(int id) {
		return repo.findById(id);
	}
}
