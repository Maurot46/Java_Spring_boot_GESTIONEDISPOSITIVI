package it.epicode_Spring_boot_gestione_dispositivi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode_Spring_boot_gestione_dispositivi.configs.NotFoundException;
import it.epicode_Spring_boot_gestione_dispositivi.entities.Dispositivo;
import it.epicode_Spring_boot_gestione_dispositivi.repositories.DispositivoRepository;

@Service
public class DispositivoService {
	@Autowired
    private DispositivoRepository dispositivoRepository;

    public List<Dispositivo> getDispositivi() {
        return dispositivoRepository.findAll();
    }

    public Dispositivo getDispositivoById(Long id) {
        return dispositivoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Dispositivo non trovato"));
    }

    public Dispositivo createDispositivo(Dispositivo dispositivo) {
        return dispositivoRepository.save(dispositivo);
    }

    public Dispositivo updateDispositivo(Long id, Dispositivo dispositivo) {
        Dispositivo existingDispositivo = dispositivoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Dispositivo non trovato"));
        existingDispositivo.setTipo(dispositivo.getTipo());
        existingDispositivo.setStato(dispositivo.getStato());
        // altri attributi
        return dispositivoRepository.save(existingDispositivo);
    }

    public void deleteDispositivo(Long id) {
        Dispositivo dispositivo = dispositivoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Dispositivo non trovato"));
        dispositivoRepository.delete(dispositivo);
    }
}
