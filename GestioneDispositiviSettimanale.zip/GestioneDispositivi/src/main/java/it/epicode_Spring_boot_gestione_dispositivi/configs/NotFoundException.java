package it.epicode_Spring_boot_gestione_dispositivi.configs;

public class NotFoundException extends RuntimeException{
	public NotFoundException(String message) {
        super(message);
    }
}
