package it.epicode_Spring_boot_gestione_dispositivi.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "dispositivi")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Dispositivo {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TipoDispositivo tipo;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatoDispositivo stato;
    
    @ManyToMany(mappedBy = "dispositivi")
    private Set<Utente> utenti = new HashSet<>();
}
