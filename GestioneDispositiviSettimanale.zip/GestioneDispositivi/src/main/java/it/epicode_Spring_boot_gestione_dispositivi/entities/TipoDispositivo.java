package it.epicode_Spring_boot_gestione_dispositivi.entities;

public enum TipoDispositivo {
	SMARTPHONE, TABLET, NOTEBOOK
}
