package it.epicode_Spring_boot_gestione_dispositivi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestioneDispositiviApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestioneDispositiviApplication.class, args);
	}

}
