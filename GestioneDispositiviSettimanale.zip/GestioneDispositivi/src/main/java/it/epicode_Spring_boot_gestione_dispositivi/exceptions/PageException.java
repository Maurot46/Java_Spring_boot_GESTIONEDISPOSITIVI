package it.epicode_Spring_boot_gestione_dispositivi.exceptions;

public class PageException extends RuntimeException{
	public PageException(String message) {
		super(message);
	}
	
}
