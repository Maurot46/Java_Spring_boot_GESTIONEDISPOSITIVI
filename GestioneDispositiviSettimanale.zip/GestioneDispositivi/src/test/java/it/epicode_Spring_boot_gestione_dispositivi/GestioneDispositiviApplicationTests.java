package it.epicode_Spring_boot_gestione_dispositivi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioneDispositiviApplicationTests {

	@Test
	void contextLoads() {
	}

}
